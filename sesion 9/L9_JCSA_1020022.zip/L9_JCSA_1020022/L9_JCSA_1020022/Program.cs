﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_JCSA_1020022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int sum = 0;

                for (int i = 2; i <= 1000; i += 2)
                {
                    sum += i;
                }

                Console.WriteLine("La suma de los números pares desde 2 hasta 1000 es: " + sum);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocurrió un error: " + ex.Message);
            }
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("En C#, el \"try catch\" es una estructura de control " +
                "que se utiliza para manejar excepciones en el código. En esencia, " +
                "el \"try catch\" permite al programador detectar errores o excepciones " +
                "en el código y proporcionar un mecanismo para manejarlos de forma segura.");
            Console.ReadKey();
        }
    }
}
